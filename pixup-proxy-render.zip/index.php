<?php
echo "PixUp Proxy online";
?>
