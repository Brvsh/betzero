# PixUp Proxy para Render

Este projeto cria um container PHP com Apache que age como intermediador entre seu servidor e a API da PixUp.

- `proxy_pixup.php`: recebe dados da Hostinger e faz requisição para PixUp.
- `Dockerfile`: base em PHP 8.1 com Apache.
